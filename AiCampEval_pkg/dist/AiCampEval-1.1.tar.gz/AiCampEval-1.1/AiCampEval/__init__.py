from .AiCampEval import eval_submit
name = 'AiCampEval'